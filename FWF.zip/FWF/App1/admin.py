from django.contrib import admin
from App1.models import *


# Register your models here.
class UserRegistrationAdmin(admin.ModelAdmin):
    list_display = ('id' ,'U_Name', 'City', 'Contact', 'Blood_Group', 'Last_Donation_Date')
    list_display_links = ('id', 'Blood_Group')
    list_per_page = 8
    search_fields = ('U_Name',)


admin.site.register(UserRegistration, UserRegistrationAdmin)


class CityAdmin(admin.ModelAdmin):
    list_display = ('id', 'City')
    list_display_links = ('City',)
    list_per_page = 8
    search_fields = ('City',)


admin.site.register(UserCity, CityAdmin)


class BGroupAdmin(admin.ModelAdmin):
    list_display = ('id', 'Blood_Group')
    list_display_links = ('Blood_Group',)
    list_per_page = 8
    search_fields = ('Blood_Group',)


admin.site.register(UserBloodGroup, BGroupAdmin)



