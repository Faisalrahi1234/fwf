from django.urls import path
from App1.views import *

urlpatterns = [
    path('', index),
]