from django.db import models


class UserCity(models.Model):
    City = models.CharField(max_length=50)

    def __str__(self):
        return self.City


class UserBloodGroup(models.Model):
    Blood_Group = models.CharField(max_length=50)

    def __str__(self):
        return self.Blood_Group


# Create your models here.
class UserRegistration(models.Model):
    U_Name = models.CharField(max_length=256)
    City = models.ForeignKey(UserCity, on_delete=models.CASCADE, blank=False)
    Contact = models.CharField(max_length=12)
    Blood_Group = models.ForeignKey(UserBloodGroup, on_delete=models.CASCADE, blank=False)
    Last_Donation_Date = models.DateField(blank=False)

    def __str__(self):
        return self.U_Name
